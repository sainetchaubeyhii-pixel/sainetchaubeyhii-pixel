<div align="center">

<img src="./assets/coding-banner.gif" width="100%" alt="Animated RISC-V coding banner"/>

<br>

<a href="https://github.com/sainetchaubeyhii-pixel">
  <img src="https://readme-typing-svg.demolab.com/?font=Fira+Code&size=24&duration=2800&pause=900&color=58A6FF&center=true&vCenter=true&width=850&lines=Hi+%F0%9F%91%8B%2C+I'm+Sainet+Chaubey;RISC-V+Processor+Designer;RTL+%7C+SoC+%7C+ASIC+Design+Enthusiast;Building+Processors+in+SystemVerilog+%E2%9A%A1;Exploring+VLSI+%26+Neural+Hardware" alt="Typing animation"/>
</a>

### ⚡ RISC-V • RTL • SoC • ASIC • VLSI

[![GitHub](https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white)](https://github.com/sainetchaubeyhii-pixel)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/)
[![SystemVerilog](https://img.shields.io/badge/SystemVerilog-RTL-0B7285?style=for-the-badge)](https://en.wikipedia.org/wiki/SystemVerilog)
[![RISC-V](https://img.shields.io/badge/RISC--V-Processor-283593?style=for-the-badge)](https://riscv.org/)

</div>

---

## 👨‍💻 About Me

```text
🎓 Electronics & Instrumentation Engineering Student
🧠 RISC-V / RV32I enthusiast
💻 SystemVerilog & Verilog RTL designer
🔌 AXI4-Lite • APB • SPI • UART • GPIO
🛠️ Cadence Xcelium • Genus • Innovus
🔬 Interested in VLSI, SoC, ASIC and neural hardware
```

## 🚀 What I'm Building

- 🧩 **RISC-V RV32I processors** and custom SoC architectures
- 🔗 **AXI4-Lite / APB peripheral integration**
- ⚡ **Low-power hardware architectures**
- 🧮 **MAC / systolic-array accelerators**
- 🏭 **RTL → synthesis → physical-design exploration**

---

## 🛠️ Tech Stack

<div align="center">

<img src="https://skillicons.dev/icons?i=c,cpp,git,github,linux,vim&perline=6" />

<br><br>

<img src="https://img.shields.io/badge/SystemVerilog-RTL-0B7285?style=for-the-badge"/>
<img src="https://img.shields.io/badge/Verilog-HDL-6A5ACD?style=for-the-badge"/>
<img src="https://img.shields.io/badge/RISC--V-RV32I-283593?style=for-the-badge"/>
<img src="https://img.shields.io/badge/AXI4--Lite-SoC-1565C0?style=for-the-badge"/>
<img src="https://img.shields.io/badge/APB-Peripheral-2E7D32?style=for-the-badge"/>
<img src="https://img.shields.io/badge/SPI-Interface-8E24AA?style=for-the-badge"/>
<img src="https://img.shields.io/badge/Cadence-Xcelium%20%7C%20Genus%20%7C%20Innovus-D32F2F?style=for-the-badge"/>

</div>

---

## 🔥 Featured Projects

<table>
<tr>
<td width="50%">

### 🧠 RISC-V 5-Stage Processor

RV32I pipelined processor designed in SystemVerilog.

**Focus:**  
Pipeline • CSR • Memory Interface • RTL

</td>
<td width="50%">

### ⚡ PicoRV32 SoC

RISC-V based SoC with peripheral integration.

**Focus:**  
AXI4-Lite • APB • SPI • UART • GPIO

</td>
</tr>

<tr>
<td width="50%">

### 🚨 PLIC IP

Programmable interrupt controller exploration for a RISC-V SoC.

**Focus:**  
Interrupts • AXI4-Lite • SoC Integration

</td>
<td width="50%">

### 🧮 Systolic Array

2×2 / 4×4 MAC-based accelerator architecture.

**Focus:**  
MAC • PE • Dataflow • ASIC

</td>
</tr>
</table>

<div align="center">

[🔗 **PicoRV32 SoC**](./PICORV32_Soc) •
[🔗 **PLIC IP**](./Plic_ip) •
[🔗 **5-Stage RISC-V**](./riscV_pipelined_5_Stage_processor_RV32I)

</div>

---

## 📊 GitHub Statistics

<div align="center">

<img src="./profile/stats.svg" width="49%" alt="GitHub statistics"/>
<img src="./profile/top-langs.svg" width="49%" alt="Top languages"/>

<br><br>

<img src="./profile/streak.svg" width="70%" alt="GitHub streak"/>

</div>

---

## 🐍 Contribution Snake

<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="./dist/github-snake-dark.svg">
  <source media="(prefers-color-scheme: light)" srcset="./dist/github-snake.svg">
  <img alt="GitHub contribution snake" src="./dist/github-snake.svg" width="90%">
</picture>

</div>

---

## ⚙️ Hardware Design Flow

```text
Architecture
     ↓
RISC-V / RTL Design
     ↓
SystemVerilog Verification
     ↓
Xcelium Simulation
     ↓
Genus Synthesis
     ↓
Floorplanning / Placement
     ↓
CTS / Routing
     ↓
ASIC Implementation
```

---

<div align="center">

### ⚡ Keep building. Keep learning. Keep designing silicon.

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:0D1117,50:161B22,100:58A6FF&height=100&section=footer"/>

</div>
